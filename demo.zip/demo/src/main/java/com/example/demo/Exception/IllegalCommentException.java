package com.example.demo.Exception;

public class IllegalCommentException extends Exception{
}

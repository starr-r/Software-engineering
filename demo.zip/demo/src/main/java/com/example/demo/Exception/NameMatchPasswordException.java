package com.example.demo.Exception;

public class NameMatchPasswordException extends Exception{
}

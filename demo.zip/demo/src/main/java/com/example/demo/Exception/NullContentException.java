package com.example.demo.Exception;

public class NullContentException extends Exception{
}

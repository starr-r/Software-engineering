package com.example.demo.Exception;

public class RemarkErrorException extends Exception{

}

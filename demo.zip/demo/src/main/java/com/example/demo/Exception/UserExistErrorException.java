package com.example.demo.Exception;

public class UserExistErrorException extends Exception{

}

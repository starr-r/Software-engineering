package com.example.demo.Exception;

public class WrongFormatException extends Exception{
}

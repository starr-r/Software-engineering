package com.example.demo.controller;

import com.example.demo.entity.Artifact;
import com.example.demo.mapper.ArtifactMapper;
import com.example.demo.mapper.CommentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ArtifactController {
    @Autowired
    ArtifactMapper artifactMapper;
    @Autowired
    CommentMapper commentMapper;

    //文物部分共有四个url,严格按照下面的url格式访问

    @GetMapping("/artifact")//文物名称

    //http://localhost:8080/artifact?artifactName=xxx

    public List<Artifact> search_by_name(String artifactName) {

        return artifactMapper.findByArtifactName(artifactName);

        //调用ArtifactMapper中的select by artifactName 将list返回至前端。
    }

    @GetMapping("/search_museum")//博物馆名称

    //http://localhost:8080/search_museum?museumName=xxx;

    public List<Artifact> search_by_museum(String museumName){

        return artifactMapper.findByLibraryName(museumName);

    }

    @GetMapping("/search_relicTime")//文物年代

    //http://localhost:8080/search_relicTime?relicTime=xxx

    public List<Artifact> search_by_time(String relicTime){

        return artifactMapper.findByRelicTime(relicTime);

    }

    @GetMapping("/artifact/{id}")//文物详情页面

    //http://localhost:8080/artifact/{id}

    public Artifact artifact_details(@PathVariable String id){

        Artifact artifact=artifactMapper.findById(Integer.parseInt(id));
        artifact.comments=commentMapper.findCommentsByArtifact_id(Integer.parseInt(id));
        System.out.println(artifact);
        return artifact;
    }
}

package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.mapper.CommentMapper;
import com.example.demo.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;


@RestController
public class UserController {
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private CommentMapper commentMapper;

    @GetMapping("/user/space/{user_id}")//用户所有评论,通过用户id返回用户信息和所有评论

    //http://localhost:8080/user/space/{user_id}

    public User history_comments(@PathVariable Integer user_id){

        User user=userMapper.findById(user_id);
        user.comments=commentMapper.findCommentsByUser_id(user_id);
        //System.out.println(user.comments);
        return user;
    }

    @PostMapping("/user/modify")//前端不用传回当前时间
    public User modify_information(User user){
        LocalDateTime localDateTime = LocalDateTime.now();
        String date = localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return userMapper.updateInfo(user,date);
    }

}

package com.example.demo.entity;

import java.util.List;

public class Artifact extends Entity{
    Integer artifactId;//文物id 主键
    String artifact_name;   //文物名称
    String Library_name;    //博物馆名称
    String reLicTime;      //文物时代
    String country;        //国家
    String material;    //类别
    String description;  //描述
    String imageUrl;    //图片原地址
    public List<Comment> comments;//对应评论

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public Integer getArtifactId() {
        return artifactId;
    }

    public void setArtifactId(Integer artifactId) {
        this.artifactId = artifactId;
    }

    public String getArtifact_name() {
        return artifact_name;
    }

    public void setArtifact_name(String artifact_name) {
        this.artifact_name = artifact_name;
    }

    public String getLibrary_name() {
        return Library_name;
    }

    public void setLibrary_name(String library_name) {
        Library_name = library_name;
    }

    public String getReLicTime() {
        return reLicTime;
    }

    public void setReLicTime(String reLicTime) {
        this.reLicTime = reLicTime;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    @Override
    public String toString() {
        return "Artifact{" +
                "artifact_id='" + artifactId + '\'' +
                ", artifact_name='" + artifact_name + '\'' +
                ", Library_name='" + Library_name + '\'' +
                ", reLicTime='" + reLicTime + '\'' +
                ", country='" + country + '\'' +
                ", material='" + material + '\'' +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                '}';
    }
}

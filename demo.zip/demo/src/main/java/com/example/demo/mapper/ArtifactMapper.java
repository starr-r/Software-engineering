package com.example.demo.mapper;

import com.example.demo.entity.Artifact;
import org.apache.ibatis.annotations.Select;
import java.util.*;

public interface ArtifactMapper {
    @Select("Select * from artifact where artifactname=#{artifactname}")
    public List<Artifact> findByArtifactName(String ArtifactName);

    @Select("Select * from artifact where library=#{libraryName}")
    public List<Artifact> findByLibraryName(String libraryName);

    @Select("Select * from artifact where relicTime=#{relicTime}")
    public List<Artifact> findByRelicTime(String relicTime);

    @Select("select * from artifact where id=#{artifact_id}")
    public Artifact findById(Integer artifact_id);
}

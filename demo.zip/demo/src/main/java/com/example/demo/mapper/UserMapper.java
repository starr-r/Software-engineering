package com.example.demo.mapper;

import com.example.demo.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.*;
@Mapper
public interface UserMapper {
    @Select("Select * from user where id=#{id}")
    public User findById(Integer id);
    @Update("update user set " +
            "username=#{user.name}," +
            "password=#{user.password}," +
            "avatar_url=#{user.avatar_url}," +
            "email=#{user.email}," +
            "phone=#{user.phone}," +
            "update_time=#{date}")
    public User updateInfo(User user,String date);

}

package com.example.demo.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.example.demo.common.Result;
import com.example.demo.entity.Wenwu;
import com.example.demo.mapper.WenwuMapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/wenwu")
@Api(tags = "文物管理接口")
public class WenwuController {

    @Resource
    WenwuMapper WenwuMapper;

    @GetMapping
    @ApiOperation("分页查询文物")
    public Result<?> findPage(
            @ApiParam(value = "页码", defaultValue = "1") @RequestParam(defaultValue ="1") Integer pageNum,
            @ApiParam(value = "每页数量", defaultValue = "10") @RequestParam(defaultValue ="10") Integer pageSize,
            @ApiParam("搜索关键词") @RequestParam(defaultValue ="") String search,
            @ApiParam("查询类型，1表示按名称查询，2表示按博物馆查询，3表示按年代查询，4表示按网址查询") @RequestParam Integer num){
        LambdaQueryWrapper<Wenwu> wrapper=Wrappers.<Wenwu>lambdaQuery();
        if(num==1){
            if(StrUtil.isNotBlank(search)){
                wrapper.like(Wenwu::getName,search);
            }
            Page<Wenwu> WenwuPage=WenwuMapper.selectPage(new Page<>(pageNum,pageSize),wrapper);
            return Result.success(WenwuPage);
        }
        else if(num==2){
            if(StrUtil.isNotBlank(search)){
                wrapper.like(Wenwu::getMuseum,search);
            }
            Page<Wenwu> WenwuPage=WenwuMapper.selectPage(new Page<>(pageNum,pageSize),wrapper);
            return Result.success(WenwuPage);
        }
        else if(num==3){
            if(StrUtil.isNotBlank(search)){
                wrapper.like(Wenwu::getDate,search);
            }
            Page<Wenwu> WenwuPage=WenwuMapper.selectPage(new Page<>(pageNum,pageSize),wrapper);
            return Result.success(WenwuPage);
        }
        else if(num==4){
            if(StrUtil.isNotBlank(search)){
                wrapper.like(Wenwu::getWebsite,search);
            }
            Page<Wenwu> WenwuPage=WenwuMapper.selectPage(new Page<>(pageNum,pageSize),wrapper);
            return Result.success(WenwuPage);
        }
        return Result.success();
    }
}

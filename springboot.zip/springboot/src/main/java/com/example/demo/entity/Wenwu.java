package com.example.demo.entity;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.sql.Date;

@TableName("Wenwu")
@Data

public class Wenwu {
    @TableId(value="id",type= IdType.AUTO)
    private Integer id;
    private String name;
    private String museum;
    private String description;
    private Date date;
    private String website;
    private String type;

    public String getName() {
        return name;
    }

    // getMuseum 方法返回博物馆名称
    public String getMuseum() {
        return museum;
    }

    // getDate 方法返回展览日期
    public Date getDate() {
        return date;
    }

    // getWebsite 方法返回展览网站
    public String getWebsite() {
        return website;
}


    }